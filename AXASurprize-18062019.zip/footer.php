<link rel="stylesheet" href="assets/css/footer.css">
<footer class="footer bg-blue">
	<div class="container-fluid">
		<div class="row">
			<div class="col-12 text-center">
				<p class="mb-0">Powered by <img src="assets/img/logo-surprize.png" alt="" class="img-fluid"></p>
			</div>
		</div>
	</div>
</footer>