<link rel="stylesheet" href="assets/css/header.css">
<header>
	<div class="container">
		<div class="row text-center align-items-center justify-content-center">
			<img src="assets/img/logo-axa.png" alt="" class="img-fluid top-logo">
			<p class="logo-separator">X</p>
			<img src="assets/img/logo-beon.png" alt="" class="img-fluid top-logo">
		</div>
	</div>
</header>