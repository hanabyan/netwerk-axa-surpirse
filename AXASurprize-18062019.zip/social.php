<link rel="stylesheet" href="assets/css/social.css">
<div class="social-wrapper text-center bg-blue d-flex justify-content-center">
	<a href="#" target="__blank">
		<i class="fab fb fa-facebook-f"></i>
	</a>
	<a href="#" target="__blank">
		<i class="fab tw fa-twitter"></i>
	</a>
	<a href="#" target="__blank">
		<i class="fab wa fa-whatsapp"></i>
	</a>
</div>